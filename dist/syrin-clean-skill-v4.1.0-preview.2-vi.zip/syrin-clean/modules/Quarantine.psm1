﻿Set-StrictMode -Version 2
Import-Module (Join-Path $PSScriptRoot 'IO.psm1')
Import-Module (Join-Path $PSScriptRoot 'Policy.psm1')

function Get-SyrinRootPath([string]$Root) {
  if (-not $Root) { $Root = Join-Path $env:LOCALAPPDATA 'SyrinClean\Quarantine' }
  return Assert-SyrinSourcePath $Root @(Get-SyrinCloudRoots)
}

function Read-SyrinRoot([string]$Root) {
  $rootPath = Get-SyrinRootPath $Root
  $markerPath = Join-Path $rootPath '.syrin-clean-root.json'
  if (-not (Test-Path -LiteralPath $markerPath)) { throw 'Unowned root. Use a new empty root; import legacy CSV explicitly.' }
  [void](Assert-SyrinLocalPath $markerPath)
  $marker = Read-SyrinJson $markerPath
  if ($marker.schemaVersion -ne 1 -or $marker.kind -ne 'syrin-quarantine' -or $marker.ownerSid -ne (Get-SyrinOwner) -or $marker.rootId -notmatch '^[a-f0-9]{32}$') { throw 'Invalid root marker or different owner.' }
  return $marker
}

function Initialize-SyrinRoot([string]$Root) {
  $rootPath = Get-SyrinRootPath $Root
  if (Test-Path -LiteralPath (Join-Path $rootPath '.syrin-clean-root.json')) { return Read-SyrinRoot $rootPath }
  if ((Test-Path -LiteralPath $rootPath) -and @(Get-ChildItem -LiteralPath $rootPath -Force -ErrorAction Stop).Count) { throw 'Refusing to adopt a non-empty directory.' }
  [void][IO.Directory]::CreateDirectory($rootPath)
  $sid = Get-SyrinOwner
  $acl = New-Object Security.AccessControl.DirectorySecurity
  $acl.SetAccessRuleProtection($true,$false)
  foreach ($identity in @($sid,'S-1-5-18')) {
    $rule = New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($identity)), 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
  }
  Set-Acl -LiteralPath $rootPath -AclObject $acl -ErrorAction Stop
  $marker = [ordered]@{schemaVersion=1;kind='syrin-quarantine';ownerSid=$sid;rootId=[guid]::NewGuid().ToString('N');createdUtc=[DateTime]::UtcNow.ToString('o')}
  Write-SyrinAtomicJson (Join-Path $rootPath '.syrin-clean-root.json') $marker -CreateOnly
  return [PSCustomObject]$marker
}

function Open-SyrinRootLock([string]$Root) {
  $path = Assert-SyrinLocalPath (Join-Path $Root '.syrin-clean.lock')
  try { return New-Object IO.FileStream($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
  catch { throw 'Another operation owns this root. Retry after it finishes.' }
}

function Get-SyrinSessionPath([string]$Root,[string]$SessionId) {
  if ($SessionId -notmatch '^[a-f0-9]{32}$') { throw 'Invalid session ID.' }
  return Assert-SyrinLocalPath (Join-Path (Join-Path $Root 'sessions') $SessionId)
}

function Read-SyrinSession([string]$Root,[string]$SessionId,[scriptblock]$OnProgress) {
  $marker = Read-SyrinRoot $Root
  $folder = Get-SyrinSessionPath $Root $SessionId
  $header = Read-SyrinJson (Join-Path $folder 'session.json')
  if ($header.schemaVersion -ne 1 -or $header.ownerSid -ne (Get-SyrinOwner) -or $header.rootId -ne $marker.rootId -or $header.sessionId -ne $SessionId) { throw 'Invalid session identity.' }
  $document=Read-SyrinJsonDocument (Join-Path $folder 'plan.json')
  if ($document.digest -ne $header.planDigest) { throw 'Session plan integrity check failed.' }
  $plan=$document.value
  $items = @{}
  foreach ($item in @($plan.items)) {
    if ($item.id -notmatch '^[a-f0-9]{32}$' -or $items.ContainsKey($item.id)) { throw 'Invalid item identity.' }
    $groupCode = if ($item.PSObject.Properties['groupId']) { [string]$item.groupId } else { '' }
    $items[$item.id] = [PSCustomObject]@{id=$item.id;code=$item.code;groupId=$groupCode;original=$item.original;stored=$item.stored;fingerprint=$item.fingerprint;state='planned';error='';restoredPath=''}
  }
  $sequence=0; $previous=''
  $eventsPath = Assert-SyrinLocalPath (Join-Path $folder 'events')
  $files=@(Get-ChildItem -LiteralPath $eventsPath -File -Filter '*.json' -ErrorAction Stop | Sort-Object Name)
  $paths=[string[]]@($files | ForEach-Object {$_.FullName})
  if($OnProgress){& $OnProgress 0 $files.Count | Out-Null}
  $batchSize=128
  for($offset=0;$offset -lt $files.Count;$offset+=$batchSize) {
    $count=[math]::Min($batchSize,$files.Count-$offset)
    foreach($document in @(Read-SyrinJsonBatch $paths $offset $count)) {
      $file=$files[$sequence];$event=$document.value
      $sequence++
      if ($file.Name -ne ('{0:D8}.json' -f $sequence) -or $event.sequence -ne $sequence -or $event.previous -ne $previous -or -not $items.ContainsKey($event.itemId)) { throw 'Journal sequence or integrity check failed.' }
      if ($event.state -notin @('planned','moving','quarantined','restoring','restored','conflict','failed','purging','purged')) { throw 'Unknown journal state.' }
      $item = $items[$event.itemId]
      $item.state=$event.state; $item.error=$event.error; $item.restoredPath=$event.restoredPath
      $previous=$document.digest
    }
    if($OnProgress){& $OnProgress $sequence $files.Count | Out-Null}
  }
  return [PSCustomObject]@{folder=$folder;header=$header;plan=$plan;items=$items;sequence=$sequence;digest=$previous}
}

function Add-SyrinEvent($Session,[string]$ItemId,[string]$State,[string]$ErrorText='',[string]$RestoredPath='') {
  $n = $Session.sequence + 1
  $event = [ordered]@{schemaVersion=1;sequence=$n;previous=$Session.digest;itemId=$ItemId;state=$State;error=$ErrorText;restoredPath=$RestoredPath;timeUtc=[DateTime]::UtcNow.ToString('o')}
  $path = Join-Path (Join-Path $Session.folder 'events') ('{0:D8}.json' -f $n)
  Write-SyrinAtomicJson $path $event -CreateOnly
  $Session.sequence=$n; $Session.digest=Get-SyrinDigest ([IO.File]::ReadAllBytes($path))
  $Session.items[$ItemId].state=$State; $Session.items[$ItemId].error=$ErrorText; $Session.items[$ItemId].restoredPath=$RestoredPath
}

function Get-SyrinStoredPath($Session,$Item,[string]$Root) {
  $path = Assert-SyrinLocalPath $Item.stored
  if ($Session.plan.operation -eq 'import') {
    $legacy = Assert-SyrinSourcePath $Session.plan.legacyRoot @(Get-SyrinCloudRoots)
    $relative = $path.Substring($legacy.TrimEnd('\').Length).TrimStart('\')
    if (-not (Test-SyrinWithin $path $legacy) -or $relative -notmatch '^\d{8}-\d{6}\\') { throw 'Legacy stored path escaped its timestamp directory.' }
  } else {
    $expected = Join-Path (Join-Path $Session.folder 'files') $Item.id
    if (-not $path.Equals($expected,[StringComparison]::OrdinalIgnoreCase)) { throw 'Stored path is not owned by this item.' }
  }
  if ($path -eq (Get-SyrinPath $Root)) { throw 'A root is not a stored file.' }
  return $path
}

function New-SyrinFilePlan {
  param([ValidateSet('quarantine','restore','purge','resume','import')][string]$Operation='quarantine',[string[]]$Path=@(),[string]$Root='',[string]$SessionId='',[string[]]$ItemId=@(),[ValidateSet('skip','rename')][string]$Conflict='skip',[string]$RestoreDirectory='', [string]$LegacyRoot='',[string]$PlanFile='',[string]$PolicyFile='')
  $Operation=$Operation.ToLowerInvariant();$Conflict=$Conflict.ToLowerInvariant()
  $protection=Get-SyrinProtection $PolicyFile
  Assert-SyrinWriteAllowed $protection
  $rootPath=Get-SyrinRootPath $Root
  $rootId=$null
  if (Test-Path -LiteralPath (Join-Path $rootPath '.syrin-clean-root.json')) { $rootId=(Read-SyrinRoot $rootPath).rootId }
  elseif ((Test-Path -LiteralPath $rootPath) -and @(Get-ChildItem -LiteralPath $rootPath -Force).Count) { throw 'Choose an empty owned quarantine root.' }
  $cloud=@(Get-SyrinCloudRoots)
  $policy=New-SyrinSourcePolicy $cloud $protection.protectedPaths
  [void](Assert-SyrinSourcePath $rootPath $cloud -Policy $policy)
  $planId=[guid]::NewGuid().ToString('N')
  $items=New-Object 'System.Collections.Generic.List[object]'
  if ($Operation -in @('quarantine','import')) { $SessionId=$planId }
  $sessionFolder=Get-SyrinSessionPath $rootPath $SessionId
  if ($Operation -eq 'quarantine') {
    if (-not $Path.Count) { throw 'Select at least one file or directory.' }
    foreach($selection in $Path){$selection=Assert-SyrinSourcePath $selection $cloud -Policy $policy;if((Test-SyrinWithin $selection $rootPath) -or (Test-SyrinWithin $rootPath $selection)){throw 'Source selection and quarantine storage cannot overlap.'}}
    foreach ($file in @(Get-SyrinFiles $Path $cloud -Policy $policy)) {
      if ((Test-SyrinWithin $file.Path $rootPath) -or (Test-SyrinWithin $rootPath $file.Path)) { throw 'Source and quarantine storage cannot overlap.' }
      if ([IO.Path]::GetPathRoot($file.Path) -ne [IO.Path]::GetPathRoot($rootPath)) { throw 'Choose a quarantine root on the same volume. Cross-volume copy-and-delete is unsupported.' }
      $id=[guid]::NewGuid().ToString('N')
      $items.Add([PSCustomObject]@{id=$id;original=$file.Path;stored=(Join-Path (Join-Path $sessionFolder 'files') $id);fingerprint=$file.Fingerprint;destination='';expectedState='planned'})
    }
  } elseif ($Operation -eq 'import') {
    $LegacyRoot=Assert-SyrinSourcePath $LegacyRoot $cloud -Policy $policy
    if ([IO.Path]::GetFileName($LegacyRoot) -notin @('Syrin-Clean-Quarantine','PC-Optimize-Quarantine')) { throw 'Only named legacy quarantine roots can be imported.' }
    if ((Test-SyrinWithin $rootPath $LegacyRoot) -or (Test-SyrinWithin $LegacyRoot $rootPath)) { throw 'Import into a separate new root; legacy metadata is not rewritten.' }
    $seen=New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($csv in @(Get-ChildItem -LiteralPath $LegacyRoot -File -Filter 'manifest*.csv' -ErrorAction Stop)) {
      [void](Assert-SyrinLocalPath $csv.FullName)
      foreach ($row in @(Import-Csv -LiteralPath $csv.FullName -Encoding UTF8 -ErrorAction Stop)) {
        $stored=Assert-SyrinLocalPath $row.Stored
        if (-not (Test-SyrinWithin $stored $LegacyRoot) -or $stored.Substring($LegacyRoot.Length).TrimStart('\') -notmatch '^\d{8}-\d{6}\\') { throw 'Unsafe stored path in legacy CSV.' }
        if (-not (Test-Path -LiteralPath $stored)) { continue }
        $original=Assert-SyrinSourcePath $row.Original $cloud -Policy $policy
        $fp=Get-SyrinFingerprint $stored
        if ($seen.Add($fp.FileId)) { $items.Add([PSCustomObject]@{id=[guid]::NewGuid().ToString('N');original=$original;stored=$stored;fingerprint=$fp;destination='';expectedState='planned'}) }
      }
    }
  } else {
    $session=Read-SyrinSession $rootPath $SessionId
    if (-not $ItemId.Count) { throw 'Select explicit item IDs from History.' }
    foreach ($id in $ItemId) {
      if (-not $session.items.ContainsKey($id)) { throw "Unknown item ID: $id" }
      $item=$session.items[$id]
      [void](Assert-SyrinSourcePath $item.original $cloud -Policy $policy)
      $stored=Get-SyrinStoredPath $session $item $rootPath
      [void](Assert-SyrinSourcePath $stored $cloud -Policy $policy)
      if ($Operation -eq 'purge' -and $session.plan.operation -eq 'import') { throw 'Imported legacy items support restore only. Restore and quarantine with the current engine before purging.' }
      if ($Operation -eq 'purge' -and $item.state -notin @('quarantined','conflict','failed')) { throw 'Only stored items can be planned for purge.' }
      if ($Operation -in @('restore','purge') -and -not (Test-SyrinFingerprint $stored $item.fingerprint)) { throw "Stored file changed or is missing: $id" }
      $destination=$item.original
      if ($RestoreDirectory) { $destination=Join-Path (Assert-SyrinSourcePath $RestoreDirectory $cloud -Policy $policy) ([IO.Path]::GetFileName($item.original)) }
      if ($Operation -eq 'restore') {
        $destination=Assert-SyrinSourcePath $destination $cloud -Policy $policy
        if (Test-SyrinWithin $destination $rootPath) { throw 'Restore destination cannot be inside quarantine storage.' }
        if ([IO.Path]::GetPathRoot($destination) -ne [IO.Path]::GetPathRoot($stored)) { throw 'Restore must stay on the same volume.' }
        if ((Test-Path -LiteralPath $destination) -and $Conflict -eq 'rename') {
          $destination=Join-Path ([IO.Path]::GetDirectoryName($destination)) (([IO.Path]::GetFileNameWithoutExtension($destination))+' (restored '+$id.Substring(0,8)+')'+[IO.Path]::GetExtension($destination))
          if (Test-Path -LiteralPath $destination) { throw 'The proposed renamed destination also exists. Choose another recovery directory.' }
        }
      }
      $items.Add([PSCustomObject]@{id=$id;original=$item.original;stored=$stored;fingerprint=$item.fingerprint;destination=$destination;expectedState=$item.state})
    }
  }
  if (-not $items.Count) { throw 'No regular files were selected.' }
  $prefix=@{quarantine='Q';restore='R';purge='P';resume='S';import='I'}[$Operation]
  for($index=0;$index -lt $items.Count;$index++){$items[$index]|Add-Member -NotePropertyName code -NotePropertyValue ($prefix+($index+1))}
  $dirMap=[ordered]@{}
  foreach($entry in $items){
    $dir=[IO.Path]::GetDirectoryName([string]$entry.original)
    if(-not $dirMap.Contains($dir)){$dirMap[$dir]=New-Object 'System.Collections.Generic.List[object]'}
    $dirMap[$dir].Add($entry)
  }
  $groups=New-Object 'System.Collections.Generic.List[object]'
  $groupIndex=0
  foreach($dir in $dirMap.Keys){
    $groupIndex++
    $gid='G'+$groupIndex
    $members=$dirMap[$dir]
    $groupBytes=0L
    foreach($m in $members){$groupBytes+=[long]$m.fingerprint.Length;$m|Add-Member -NotePropertyName groupId -NotePropertyValue $gid}
    $samples=@($members | Select-Object -First 3 | ForEach-Object {[IO.Path]::GetFileName([string]$_.original)})
    $groups.Add([PSCustomObject]@{groupId=$gid;directory=$dir;itemCount=$members.Count;measuredBytes=$groupBytes;firstCode=$members[0].code;lastCode=$members[$members.Count-1].code;sampleFiles=$samples})
  }
  $totalBytes=0L;foreach($entry in $items){$totalBytes+=[long]$entry.fingerprint.Length}
  $plan=[ordered]@{schemaVersion=1;kind='syrin-file-plan';planId=$planId;sessionId=$SessionId;operation=$Operation;ownerSid=(Get-SyrinOwner);root=$rootPath;rootId=$rootId;legacyRoot=$LegacyRoot;createdUtc=[DateTime]::UtcNow.ToString('o');conflict=$Conflict;groups=$groups.ToArray();items=$items.ToArray();measuredBytes=$totalBytes;estimatedReclaimableBytes=$null;warnings=@('No content was read. File identity and metadata are checked again before execution.','Unknown cloud-provider locations must be excluded explicitly.')}
  if ($Operation -eq 'quarantine') { $plan.estimatedReclaimableBytes=0 }
  $plan.protection=$protection
  if ($Operation -eq 'purge') { $plan.estimatedReclaimableBytes=$plan.measuredBytes; $plan.warnings+= 'Purge is irreversible. Logical file length is only an estimate of disk space recovered.' }
  if (-not $PlanFile) { return [PSCustomObject]@{ok=$true;previewOnly=$true;plan=[PSCustomObject]$plan;approval=$null} }
  $planPath=Assert-SyrinLocalPath $PlanFile
  if (Test-SyrinWithin $planPath $rootPath) { throw 'Keep the plan in the working directory, outside quarantine storage.' }
  if($Operation -eq 'quarantine'){foreach($selection in $Path){if(Test-SyrinWithin $planPath (Get-SyrinPath $selection)){throw 'Keep the plan outside the selected source files and directories.'}}}
  if(Test-Path -LiteralPath $planPath){$existing=Read-SyrinJson $planPath;if(-not $existing.PSObject.Properties['kind'] -or $existing.kind -ne 'syrin-file-plan'){throw 'Refusing to overwrite a file that is not a Syrin clean plan.'}}
  Write-SyrinAtomicJson $planPath $plan
  return [PSCustomObject]@{ok=$true;planFile=$planPath;approval=(Get-SyrinDigest ([IO.File]::ReadAllBytes($planPath)));plan=[PSCustomObject]$plan}
}

function New-SyrinSession([string]$Root,$Marker,$Plan,[string]$PlanText) {
  $folder=Get-SyrinSessionPath $Root $Plan.sessionId
  [void][IO.Directory]::CreateDirectory($folder)
  foreach ($name in @('events','files','approvals')) { [void][IO.Directory]::CreateDirectory((Join-Path $folder $name)) }
  Write-SyrinAtomicText (Join-Path $folder 'plan.json') $PlanText -CreateOnly
  $digest=Get-SyrinDigest ([IO.File]::ReadAllBytes((Join-Path $folder 'plan.json')))
  $header=[ordered]@{schemaVersion=1;sessionId=$Plan.sessionId;rootId=$Marker.rootId;ownerSid=(Get-SyrinOwner);createdUtc=$Plan.createdUtc;planDigest=$digest}
  Write-SyrinAtomicJson (Join-Path $folder 'session.json') $header -CreateOnly
  return Read-SyrinSession $Root $Plan.sessionId
}

function Invoke-SyrinFilePlan {
  param([string]$PlanFile,[string]$Approval,[string[]]$ItemId=@(),[string[]]$GroupId=@(),[string]$StopFile='',[string]$RunId='')
  $planPath=Assert-SyrinLocalPath $PlanFile
  $document=Read-SyrinJsonDocument $planPath
  $digest=$document.digest
  if ($Approval -notmatch '^[a-f0-9]{64}$' -or $digest -cne $Approval) { throw 'Approval digest does not match. Review the current plan again.' }
  $plan=$document.value
  if ($plan.schemaVersion -ne 1 -or $plan.kind -ne 'syrin-file-plan' -or $plan.ownerSid -ne (Get-SyrinOwner)) { throw 'Invalid plan schema or owner.' }
  if ($plan.operation -notin @('quarantine','restore','purge','resume','import')) { throw 'Unsupported operation.' }
  $expectedProtection=if($plan.PSObject.Properties['protection']){$plan.protection}else{$null}
  $protection=Get-SyrinProtection -Expected $expectedProtection
  Assert-SyrinWriteAllowed $protection
  $cloud=@(Get-SyrinCloudRoots)
  $policy=New-SyrinSourcePolicy $cloud $protection.protectedPaths
  if($StopFile){
    $StopFile=Assert-SyrinLocalPath $StopFile
    if($RunId -notmatch '^[a-f0-9]{32}$'){throw 'Stop requests require a unique 32-character run ID.'}
  } elseif($RunId){throw 'Run ID requires a stop file.'}
  if ($ItemId.Count -and @($ItemId | Select-Object -Unique).Count -ne $ItemId.Count) { throw 'An explicit unique selection of item IDs is required.' }
  if ($GroupId.Count -and @($GroupId | Select-Object -Unique).Count -ne $GroupId.Count) { throw 'An explicit unique selection of group IDs is required.' }
  $resolvedIds = New-Object 'System.Collections.Generic.List[string]'
  $seenIds = New-Object 'System.Collections.Generic.HashSet[string]'
  foreach ($id in $ItemId) { if ($seenIds.Add($id)) { $resolvedIds.Add($id) } }
  if ($GroupId.Count) {
    if (-not $plan.PSObject.Properties['groups'] -or -not @($plan.groups).Count) { throw 'This plan has no directory groups; select explicit item IDs.' }
    $knownGroups = @($plan.groups | ForEach-Object { [string]$_.groupId })
    foreach ($gid in $GroupId) { if ($gid -notin $knownGroups) { throw "Selection contains a group outside this plan: $gid" } }
    foreach ($entry in @($plan.items | Where-Object { $_.PSObject.Properties['groupId'] -and $_.groupId -in $GroupId })) {
      if ($seenIds.Add([string]$entry.id)) { $resolvedIds.Add([string]$entry.id) }
    }
  }
  $ItemId = $resolvedIds.ToArray()
  if (-not $ItemId.Count) { throw 'An explicit unique selection of item IDs is required.' }
  $selected=@($plan.items | Where-Object {$_.id -in $ItemId})
  if ($selected.Count -ne $ItemId.Count) { throw 'Selection contains an item outside this plan.' }
  $root=Get-SyrinRootPath $plan.root
  [void](Assert-SyrinSourcePath $root $cloud -Policy $policy)
  foreach($requested in $selected){
    [void](Assert-SyrinSourcePath $requested.original $cloud -Policy $policy)
    [void](Assert-SyrinSourcePath $requested.stored $cloud -Policy $policy)
    if($plan.operation -eq 'restore'){[void](Assert-SyrinSourcePath $requested.destination $cloud -Policy $policy)}
  }
  if($StopFile){
    if(Test-SyrinWithin $StopFile $root){throw 'Keep the stop request outside quarantine storage.'}
    foreach($requested in $selected){if($StopFile -in @($requested.original,$requested.destination,$planPath)){throw 'Stop request overlaps an operation input.'}}
  }
  $marker=Initialize-SyrinRoot $root
  if ($plan.rootId -and $plan.rootId -ne $marker.rootId) { throw 'Root identity changed after planning.' }
  $lock=Open-SyrinRootLock $root
  $outcomes=New-Object 'System.Collections.Generic.List[object]'
  $stopped=$false;$stopReason=''
  try {
    $folder=Get-SyrinSessionPath $root $plan.sessionId
    if (Test-Path -LiteralPath (Join-Path $folder 'session.json')) { $session=Read-SyrinSession $root $plan.sessionId }
    elseif ($plan.operation -in @('quarantine','import')) { $session=New-SyrinSession $root $marker $plan $document.text }
    else { throw 'Session does not exist.' }
    if ($plan.operation -in @('quarantine','import') -and $session.plan.planId -ne $plan.planId) { throw 'Session plan mismatch.' }
    foreach($requested in $selected){
      if(-not $session.items.ContainsKey($requested.id)){throw 'An item is not part of the source session.'}
      $current=$session.items[$requested.id]
      $repeat=($plan.operation -in @('quarantine','import') -and $current.state -eq 'quarantined') -or ($plan.operation -eq 'restore' -and $current.state -eq 'restored') -or ($plan.operation -eq 'purge' -and $current.state -eq 'purged')
      if($current.state -ne $requested.expectedState -and -not $repeat){throw 'Session state changed after planning; create and review a new plan.'}
      if($requested.original -ne $current.original -or $requested.stored -ne $current.stored -or $requested.fingerprint.FileId -ne $current.fingerprint.FileId){throw 'Item identity differs from its source session.'}
    }
    $receipt=Join-Path (Join-Path $session.folder 'approvals') ([guid]::NewGuid().ToString('N')+'.json')
    Write-SyrinAtomicJson $receipt ([ordered]@{schemaVersion=1;kind='syrin-approval-receipt';planId=$plan.planId;sessionId=$plan.sessionId;operation=$plan.operation;digest=$digest;selected=$ItemId;selectedGroups=@($GroupId);timeUtc=[DateTime]::UtcNow.ToString('o')}) -CreateOnly
    foreach ($requested in $selected) {
      try {
        if($StopFile -and (Test-Path -LiteralPath $StopFile)){
          $stop=Read-SyrinJson $StopFile
          if($stop.kind -cne 'syrin-stop' -or $stop.schemaVersion -ne 1 -or $stop.runId -cne $RunId){throw 'Stop request does not match this run. No further items will start.'}
          $stopped=$true;$stopReason='Requested by the caller.';break
        }
        $protection=Get-SyrinProtection -Expected $expectedProtection
        Assert-SyrinWriteAllowed $protection
        $policy=New-SyrinSourcePolicy $cloud $protection.protectedPaths
        [void](Assert-SyrinSourcePath $requested.original $cloud -Policy $policy)
        [void](Assert-SyrinSourcePath $requested.stored $cloud -Policy $policy)
      } catch {$stopped=$true;$stopReason=$_.Exception.Message;break}
      if (-not $session.items.ContainsKey($requested.id)) { throw 'Selected item is not part of the source session.' }
      $item=$session.items[$requested.id]
      $stored=Get-SyrinStoredPath $session $item $root
      $state=$item.state; $errorText=''
      try {
        if ($requested.original -ne $item.original -or $requested.stored -ne $item.stored -or $requested.fingerprint.FileId -ne $item.fingerprint.FileId) { throw 'Item changed since planning.' }
        if ($plan.operation -eq 'import') {
          if (-not (Test-SyrinFingerprint $stored $item.fingerprint)) { throw 'Legacy file identity changed.' }
          Add-SyrinEvent $session $item.id 'quarantined'
        } elseif ($plan.operation -eq 'quarantine') {
          [void](Assert-SyrinSourcePath $item.original $cloud -Policy $policy)
          if ((Test-SyrinWithin $item.original $root) -or (Test-SyrinWithin $root $item.original)) { throw 'Source overlaps storage.' }
          if ([IO.Path]::GetPathRoot($stored) -ne [IO.Path]::GetPathRoot($item.original)) { throw 'Cross-volume transfers are unsupported.' }
          if ($item.state -eq 'quarantined' -and (Test-SyrinFingerprint $stored $item.fingerprint)) { $outcomes.Add([PSCustomObject]@{id=$item.id;state='quarantined';error='';unchanged=$true}); continue }
          if (-not (Test-SyrinFingerprint $item.original $item.fingerprint) -or (Test-Path -LiteralPath $stored)) { throw 'Source changed or destination exists. Use a new plan or Resume.' }
          Add-SyrinEvent $session $item.id 'moving'
          [void](Assert-SyrinLocalPath $stored)
          if(-not (Test-SyrinFingerprint $item.original $item.fingerprint)){throw 'Source changed while preparing the journal.'}
          Move-SyrinCheckedFile $item.original $stored $item.fingerprint
          try { if(-not (Test-SyrinFingerprint $stored $item.fingerprint)){throw 'Source changed during transfer.'}; Add-SyrinEvent $session $item.id 'quarantined' }
          catch {
            if (-not (Test-Path -LiteralPath $item.original) -and (Test-SyrinFingerprint $stored $item.fingerprint)) { Move-SyrinCheckedFile $stored $item.original $item.fingerprint }
            throw 'Journal commit failed after move. Original was restored when safe; use Resume to reconcile.'
          }
        } elseif ($plan.operation -eq 'restore') {
          if ($item.state -eq 'restored' -and $item.restoredPath -eq $requested.destination -and -not (Test-Path -LiteralPath $stored)) { $outcomes.Add([PSCustomObject]@{id=$item.id;state='restored';error='';unchanged=$true}); continue }
          if (-not (Test-SyrinFingerprint $stored $item.fingerprint)) { throw 'Stored file changed or is missing.' }
          $destination=Assert-SyrinSourcePath $requested.destination $cloud -Policy $policy
          if (Test-SyrinWithin $destination $root) { throw 'Restore destination overlaps storage.' }
          if ([IO.Path]::GetPathRoot($destination) -ne [IO.Path]::GetPathRoot($stored)) { throw 'Cross-volume restore is unsupported.' }
          if (Test-Path -LiteralPath $destination) { Add-SyrinEvent $session $item.id 'conflict' 'Destination already exists.'; $outcomes.Add([PSCustomObject]@{id=$item.id;state='conflict';error='Destination already exists.'}); continue }
          [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination))
          [void](Assert-SyrinSourcePath $destination $cloud -Policy $policy)
          Add-SyrinEvent $session $item.id 'restoring' '' $destination
          if(-not (Test-SyrinFingerprint $stored $item.fingerprint)){throw 'Stored file changed while preparing restore.'}
          Move-SyrinCheckedFile $stored $destination $item.fingerprint
          try { Add-SyrinEvent $session $item.id 'restored' '' $destination }
          catch { throw 'Restore completed but its journal commit failed. Use Resume; do not repeat the move.' }
        } elseif ($plan.operation -eq 'purge') {
          if ($session.plan.operation -eq 'import') { throw 'Legacy imports cannot be purged.' }
          if ($item.state -eq 'purged' -and -not (Test-Path -LiteralPath $stored)) { $outcomes.Add([PSCustomObject]@{id=$item.id;state='purged';error='';unchanged=$true}); continue }
          if (-not (Test-SyrinFingerprint $stored $item.fingerprint)) { throw 'Stored file changed or is missing.' }
          Add-SyrinEvent $session $item.id 'purging'
          [void](Assert-SyrinLocalPath $stored)
          Remove-SyrinCheckedFile $stored $item.fingerprint
          Add-SyrinEvent $session $item.id 'purged'
        } else {
          if($item.state -in @('restored','purged')){$outcomes.Add([PSCustomObject]@{id=$item.id;state=$item.state;error='';unchanged=$true});continue}
          if ($item.state -eq 'moving' -and (Test-SyrinFingerprint $stored $item.fingerprint) -and -not (Test-Path -LiteralPath $item.original)) { Add-SyrinEvent $session $item.id 'quarantined' }
          elseif ($item.state -in @('moving','failed') -and (Test-SyrinFingerprint $item.original $item.fingerprint) -and -not (Test-Path -LiteralPath $stored)) { Add-SyrinEvent $session $item.id 'planned' }
          elseif ($item.state -eq 'restoring' -and $item.restoredPath -and (Test-SyrinFingerprint $item.restoredPath $item.fingerprint) -and -not (Test-Path -LiteralPath $stored)) { Add-SyrinEvent $session $item.id 'restored' '' $item.restoredPath }
          elseif ($item.state -in @('moving','restoring','purging','quarantined','conflict','failed') -and (Test-SyrinFingerprint $stored $item.fingerprint)) { Add-SyrinEvent $session $item.id 'quarantined' }
          else { throw 'State is ambiguous. No file was moved or deleted; inspect history and the recorded paths.' }
        }
        $state=$session.items[$item.id].state
      } catch {
        $errorText=$_.Exception.Message
        $state=$session.items[$item.id].state
        if ($state -notin @('moving','restoring','purging','restored','purged')) {
          try { Add-SyrinEvent $session $item.id 'failed' $errorText; $state='failed' } catch { $errorText+=' Journal error: '+$_.Exception.Message }
        }
      }
      $outcomes.Add([PSCustomObject]@{id=$item.id;state=$state;error=$errorText})
      if ($errorText) { break }
    }
  } finally { $lock.Dispose() }
  $ok=@($outcomes | Where-Object {$_.error -or $_.state -eq 'conflict'}).Count -eq 0 -and $outcomes.Count -eq $selected.Count
  return [PSCustomObject]@{ok=$ok;schemaVersion=1;sessionId=$plan.sessionId;operation=$plan.operation;root=$root;runId=$RunId;stopped=$stopped;stopReason=$stopReason;items=$outcomes.ToArray();unprocessed=@($ItemId | Where-Object {$_ -notin @($outcomes | ForEach-Object {$_.id})})}
}

function Get-SyrinHistory([string]$Root='',[string]$SessionId='',[scriptblock]$OnProgress) {
  $rootPath=Get-SyrinRootPath $Root
  if (-not (Test-Path -LiteralPath $rootPath)) { return @() }
  [void](Read-SyrinRoot $rootPath)
  $sessionsPath=Join-Path $rootPath 'sessions'
  if (-not (Test-Path -LiteralPath $sessionsPath)) { return @() }
  $ids=if ($SessionId) {@($SessionId)} else {@(Get-ChildItem -LiteralPath $sessionsPath -Directory | ForEach-Object {$_.Name})}
  $progress=[ordered]@{sessionsProcessed=0;sessionsTotal=@($ids).Count;sessionsFailed=0;activeSession=$null;sessionEventsVerified=0;sessionEventsTotal=0;eventsVerified=0}
  foreach ($id in $ids) {
    $progress.activeSession=$id;$progress.sessionEventsVerified=0;$progress.sessionEventsTotal=0
    if($OnProgress){& $OnProgress ([PSCustomObject]$progress) | Out-Null}
    $onEvents=$null
    if($OnProgress){
      $onEvents={param($Verified,$Total)
        $progress.eventsVerified+=$Verified-$progress.sessionEventsVerified
        $progress.sessionEventsVerified=$Verified;$progress.sessionEventsTotal=$Total
        try{& $OnProgress ([PSCustomObject]$progress) | Out-Null}
        catch{throw [OperationCanceledException]::new('History progress reporting failed.',$_.Exception)}
      }.GetNewClosure()
    }
    try {
      $session=Read-SyrinSession $rootPath $id -OnProgress $onEvents
      [PSCustomObject]@{ok=$true;sessionId=$id;createdUtc=$session.header.createdUtc;operation=$session.plan.operation;items=@($session.items.Values | Sort-Object original)}
    } catch {
      if($_.Exception -is [OperationCanceledException]){throw}
      $progress.sessionsFailed++
      [PSCustomObject]@{ok=$false;sessionId=$id;error=$_.Exception.Message;items=@()}
    }
    $progress.sessionsProcessed++;$progress.activeSession=$null
    if($OnProgress){& $OnProgress ([PSCustomObject]$progress) | Out-Null}
  }
}

function Test-SyrinRecovery([string]$Root='',[string]$SessionId='') {
  $rootPath=Get-SyrinRootPath $Root
  $results=New-Object 'System.Collections.Generic.List[object]'
  if(-not(Test-Path -LiteralPath $rootPath)){return [PSCustomObject]@{ok=$true;sessions=@();checkedUtc=[DateTime]::UtcNow.ToString('o')}}
  [void](Read-SyrinRoot $rootPath)
  $lock=Open-SyrinRootLock $rootPath
  try {
    $ids=if($SessionId){@($SessionId)}else{@(Get-ChildItem -LiteralPath (Join-Path $rootPath 'sessions') -Directory -ErrorAction Stop | ForEach-Object {$_.Name})}
    foreach($id in $ids){
      try {
        $session=Read-SyrinSession $rootPath $id
        $items=@(foreach($item in $session.items.Values){
          $status='not-stored';$errorText=''
          try {
            $stored=Get-SyrinStoredPath $session $item $rootPath
            if($item.state -in @('quarantined','conflict','failed','moving','restoring','purging')){
              $status=if(-not(Test-Path -LiteralPath $stored)){'missing'}elseif(Test-SyrinFingerprint $stored $item.fingerprint){'intact'}else{'changed'}
              if($item.state -in @('moving','restoring','purging')){$status='reconcile-required'}
            } elseif(Test-Path -LiteralPath $stored){$status='unexpected-stored-file'}
          } catch {$status='unverified';$errorText=$_.Exception.Message}
          [PSCustomObject]@{id=$item.id;state=$item.state;integrity=$status;error=$errorText}
        })
        $known=@($session.items.Keys)
        $unlisted=@(Get-ChildItem -LiteralPath (Assert-SyrinLocalPath (Join-Path $session.folder 'files')) -Force -ErrorAction Stop | Where-Object {$_.Name -notin $known} | ForEach-Object {$_.Name})
        $ok=@($items | Where-Object {$_.integrity -notin @('intact','not-stored')}).Count -eq 0 -and $unlisted.Count -eq 0
        $results.Add([PSCustomObject]@{ok=$ok;sessionId=$id;items=$items;unlisted=$unlisted})
      } catch {$results.Add([PSCustomObject]@{ok=$false;sessionId=$id;error=$_.Exception.Message;items=@();unlisted=@()})}
    }
  } finally {$lock.Dispose()}
  return [PSCustomObject]@{ok=@($results | Where-Object {-not $_.ok}).Count -eq 0;sessions=$results.ToArray();checkedUtc=[DateTime]::UtcNow.ToString('o')}
}

Export-ModuleMember -Function New-SyrinFilePlan,Invoke-SyrinFilePlan,Get-SyrinHistory,Test-SyrinRecovery
